package util;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.siyal.roomwordssample.MainActivity;
import com.siyal.roomwordssample.NewWordActivity;
import com.siyal.roomwordssample.R;

import java.util.List;

import entity.Word;

public class WordListAdapter extends RecyclerView.Adapter<WordListAdapter.WordViewHolder>{

    private Context context;
    private LayoutInflater mInflater;
    private List<Word> mWords; // Cached copy of words

    public WordListAdapter(Context context){
        this.context = context;
        mInflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public WordViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.recyclerview_item, parent, false);
        return new WordViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull WordViewHolder holder, int position) {
        if (mWords != null) {
            Word current = mWords.get(position);
            holder.wordItemView.setText(current.getWord());
        } else {
            // Covers the case of data not being ready yet.
            holder.wordItemView.setText("No Word");
        }
    }

    // getItemCount() is called many times, and when it is first called,
    // mWords has not been updated (means initially, it's null, and we can't return null).
    @Override
    public int getItemCount() {
        if (mWords != null)
            return mWords.size();
        return 0;
    }

    public void setWords(List<Word> words){
        mWords = words;
        notifyDataSetChanged();
    }

    public Word getWordAtPosition (int position) {
        return mWords.get(position);
    }


    public class WordViewHolder extends RecyclerView.ViewHolder {

        private TextView wordItemView;

        public WordViewHolder(@NonNull View itemView) {
            super(itemView);
            wordItemView = itemView.findViewById(R.id.textView);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, NewWordActivity.class);
                    intent.putExtra(MainActivity.EXTRA_DATA_UPDATE_WORD, mWords.get(getAdapterPosition()).getWord());
                    intent.putExtra(MainActivity.EXTRA_DATA_ID, mWords.get(getAdapterPosition()).getId());
                    ((Activity) context).startActivityForResult(intent, MainActivity.UPDATE_WORD_ACTIVITY_REQUEST_CODE);
                }
            });
        }
    }
}
