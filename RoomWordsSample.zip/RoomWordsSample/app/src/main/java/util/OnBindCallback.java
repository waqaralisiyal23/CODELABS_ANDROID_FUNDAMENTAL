package util;

public interface OnBindCallback {
    void onViewBound(WordListAdapter.WordViewHolder viewHolder, int position);
}
